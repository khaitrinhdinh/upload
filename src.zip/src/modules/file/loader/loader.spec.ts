import { Loader } from './loader';

describe('Loader', () => {
  it('should be defined', () => {
    expect(new Loader()).toBeDefined();
  });
});
