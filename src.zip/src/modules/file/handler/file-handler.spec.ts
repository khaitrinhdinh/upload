import { FileHandler } from './file-handler';

describe('FileHandler', () => {
  it('should be defined', () => {
    expect(new FileHandler()).toBeDefined();
  });
});
